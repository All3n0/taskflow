(function () {
  console.log('🔥 TaskFlow sync script loaded for web app');

  let syncInterval = null;
  let isExtensionConnected = true;

  // Check if extension is still valid
  function isExtensionValid() {
    try {
      return !!chrome.runtime?.id;
    } catch (e) {
      return false;
    }
  }

  // Safe message sender
  function sendMessage(message, callback) {
    try {
      if (!isExtensionValid()) {
        console.log('⏳ Extension not connected');
        isExtensionConnected = false;
        return false;
      }

      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          console.log('📡 Extension error:', chrome.runtime.lastError.message);
          isExtensionConnected = false;
          if (callback) callback(null);
        } else {
          isExtensionConnected = true;
          if (callback) callback(response);
        }
      });
      return true;
    } catch (e) {
      console.log('❌ Send failed:', e.message);
      isExtensionConnected = false;
      return false;
    }
  }

  // Listen for updates from background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'TASKS_UPDATED') {
      console.log('📥 Received tasks update from extension:', msg.tasks.length, 'tasks');
      
      // Update localStorage with the new tasks
      try {
        localStorage.setItem('kazistack-tasks', JSON.stringify(msg.tasks));
        console.log('✅ Updated web app localStorage with', msg.tasks.length, 'tasks');
        
        // Dispatch an event so the web app knows to refresh
        window.dispatchEvent(new CustomEvent('taskflow-tasks-updated', { 
          detail: { tasks: msg.tasks } 
        }));
      } catch (e) {
        console.error('❌ Failed to update localStorage:', e);
      }
    }
  });

  // Main sync function - sends web app tasks to extension
  function syncToExtension() {
    try {
      if (!isExtensionValid()) {
        return;
      }

      // Get tasks from localStorage
      const raw = localStorage.getItem('kazistack-tasks');
      if (!raw) {
        console.log('📭 No tasks found in web app');
        return;
      }

      // Parse tasks
      let tasks;
      try {
        tasks = JSON.parse(raw);
      } catch (e) {
        console.log('❌ Failed to parse tasks:', e.message);
        return;
      }

      // Handle different formats
      let taskArray = null;
      if (Array.isArray(tasks)) {
        taskArray = tasks;
      } else if (tasks?.tasks && Array.isArray(tasks.tasks)) {
        taskArray = tasks.tasks;
      } else if (tasks?.data && Array.isArray(tasks.data)) {
        taskArray = tasks.data;
      }

      if (!taskArray || taskArray.length === 0) {
        return;
      }

      console.log(`📤 Syncing ${taskArray.length} tasks to extension...`);

      // Send to extension
      sendMessage({ 
        type: 'SAVE_TASKS', 
        tasks: taskArray 
      }, (response) => {
        if (response) {
          console.log('✅ Tasks synced to extension successfully!');
        }
      });

    } catch (e) {
      console.error('💥 Sync error:', e);
    }
  }

  // Initial sync
  setTimeout(() => {
    console.log('🚀 Starting initial sync from web app...');
    syncToExtension();
  }, 2000);

  // Sync every 10 seconds
  syncInterval = setInterval(syncToExtension, 10000);

  // Sync when localStorage changes (tasks added/updated in web app)
  const originalSetItem = localStorage.setItem;
  localStorage.setItem = function(key, value) {
    // Call original
    originalSetItem.call(this, key, value);
    
    // If it's our tasks key, sync to extension
    if (key === 'kazistack-tasks') {
      console.log('✏️ Web app tasks updated, syncing to extension...');
      setTimeout(syncToExtension, 500);
    }
  };

  // Also sync when page becomes visible
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && isExtensionValid()) {
      console.log('👀 Page visible, syncing...');
      syncToExtension();
    }
  });

  // Clean up
  window.addEventListener('beforeunload', () => {
    if (syncInterval) {
      clearInterval(syncInterval);
    }
  });

  console.log('✅ Web app sync script fully initialized');
})();
(function () {
  function sync() {
    try {
      const raw = localStorage.getItem('taskflow-tasks');
      if (!raw) return;
      const tasks = JSON.parse(raw);
      chrome.runtime.sendMessage({ type: 'SAVE_TASKS', tasks });
    } catch (e) {}
  }

  // Sync immediately and every 10 seconds while on the app
  sync();
  setInterval(sync, 10000);

  // Also sync whenever localStorage changes (task added/edited/deleted)
  const _setItem = localStorage.setItem.bind(localStorage);
  localStorage.setItem = function (key, value) {
    _setItem(key, value);
    if (key === 'taskflow-tasks') {
      try {
        chrome.runtime.sendMessage({ type: 'SAVE_TASKS', tasks: JSON.parse(value) });
      } catch (e) {}
    }
  };
})();
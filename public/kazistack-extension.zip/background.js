chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SAVE_TASKS') {
    chrome.storage.local.set({ 'kazistack-tasks': msg.tasks });
    return;
  }

  if (msg.type === 'GET_TASKS') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      sendResponse({ tasks: r['kazistack-tasks'] || [] });
    });
    return true;
  }

  if (msg.type === 'MARK_DONE') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      const updated = tasks.map(t =>
        t.id === msg.taskId
          ? { ...t, status: 'done', completedAt: new Date().toISOString() }
          : t
      );
      chrome.storage.local.set({ 'kazistack-tasks': updated });
      sendResponse({ tasks: updated });
    });
    return true;
  }
});

// Check due tasks every minute
chrome.alarms.create('check-due', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'check-due') return;
  chrome.storage.local.get(['kazistack-tasks'], r => {
    const tasks = r['kazistack-tasks'] || [];
    const now = new Date();
    tasks.forEach(task => {
      if (!task.dueDate || task.status === 'done') return;
      const diff = (new Date(task.dueDate) - now) / 60000;
      if (diff > 0 && diff <= 1) {
        chrome.notifications.create(`due-${task.id}`, {
          type: 'basic',
          iconUrl: 'icon.png',
          title: `⏰ ${task.title}`,
          message: `Due now · ${task.priority} priority`,
          buttons: [{ title: '✓ Mark Done' }],
          requireInteraction: true,
        });
      }
    });
  });
});

chrome.notifications.onButtonClicked.addListener((notifId, btnIdx) => {
  if (btnIdx !== 0) return;
  const taskId = notifId.replace('due-', '');
  chrome.storage.local.get(['kazistack-tasks'], r => {
    const updated = (r['kazistack-tasks'] || []).map(t =>
      t.id === taskId ? { ...t, status: 'done', completedAt: new Date().toISOString() } : t
    );
    chrome.storage.local.set({ 'kazistack-tasks': updated });
    chrome.notifications.clear(notifId);
  });
});
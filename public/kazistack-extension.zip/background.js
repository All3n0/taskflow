// TaskFlow Background Service Worker
console.log('🚀 TaskFlow background service worker started');

// Message handler
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('📨 Background received:', msg.type);

  // Ping handler - for connection testing
  if (msg.type === 'PING') {
    sendResponse({ pong: true });
    return true;
  }

  // Save tasks to storage
  if (msg.type === 'SAVE_TASKS') {
    chrome.storage.local.set({ 'kazistack-tasks': msg.tasks }, () => {
      if (chrome.runtime.lastError) {
        console.error('❌ Save error:', chrome.runtime.lastError);
        sendResponse({ success: false, error: chrome.runtime.lastError });
      } else {
        console.log('💾 Saved', msg.tasks.length, 'tasks to storage');
        
        // Notify all tabs that tasks have been updated
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && !tab.url.includes('chrome://')) {
              chrome.tabs.sendMessage(tab.id, { 
                type: 'TASKS_UPDATED', 
                tasks: msg.tasks 
              }).catch(() => {
                // Ignore errors - tab might not have content script
              });
            }
          });
        });
        
        sendResponse({ success: true, count: msg.tasks.length });
      }
    });
    return true;
  }

  // Get tasks from storage
  if (msg.type === 'GET_TASKS') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      console.log('📤 Sending', tasks.length, 'tasks to content');
      sendResponse({ tasks });
    });
    return true;
  }

  // Mark a task as done
  if (msg.type === 'MARK_DONE') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      const updated = tasks.map(t =>
        t.id === msg.taskId
          ? { ...t, status: 'done', completedAt: new Date().toISOString() }
          : t
      );
      
      chrome.storage.local.set({ 'kazistack-tasks': updated }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Mark done error:', chrome.runtime.lastError);
          sendResponse({ success: false, error: chrome.runtime.lastError });
        } else {
          console.log('✅ Marked task', msg.taskId, 'as done');
          
          // Notify all tabs about the update
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              if (tab.url && !tab.url.includes('chrome://')) {
                chrome.tabs.sendMessage(tab.id, { 
                  type: 'TASKS_UPDATED', 
                  tasks: updated 
                }).catch(() => {});
              }
            });
          });
          
          sendResponse({ tasks: updated, success: true });
        }
      });
    });
    return true;
  }

  // Add a new task
  if (msg.type === 'ADD_TASK') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      const newTask = {
        ...msg.task,
        id: msg.task.id || Date.now().toString(36) + Math.random().toString(36).substring(2),
        createdAt: msg.task.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const updated = [...tasks, newTask];
      
      chrome.storage.local.set({ 'kazistack-tasks': updated }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Add task error:', chrome.runtime.lastError);
          sendResponse({ success: false, error: chrome.runtime.lastError });
        } else {
          console.log('➕ Added new task:', newTask.title);
          
          // Notify all tabs about the update
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              if (tab.url && !tab.url.includes('chrome://')) {
                chrome.tabs.sendMessage(tab.id, { 
                  type: 'TASKS_UPDATED', 
                  tasks: updated 
                }).catch(() => {});
              }
            });
          });
          
          sendResponse({ tasks: updated, task: newTask, success: true });
        }
      });
    });
    return true;
  }

  // Delete a task
  if (msg.type === 'DELETE_TASK') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      const updated = tasks.filter(t => t.id !== msg.taskId);
      
      chrome.storage.local.set({ 'kazistack-tasks': updated }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Delete error:', chrome.runtime.lastError);
          sendResponse({ success: false, error: chrome.runtime.lastError });
        } else {
          console.log('🗑️ Deleted task:', msg.taskId);
          
          // Notify all tabs about the update
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              if (tab.url && !tab.url.includes('chrome://')) {
                chrome.tabs.sendMessage(tab.id, { 
                  type: 'TASKS_UPDATED', 
                  tasks: updated 
                }).catch(() => {});
              }
            });
          });
          
          sendResponse({ tasks: updated, success: true });
        }
      });
    });
    return true;
  }

  // Update a task
  if (msg.type === 'UPDATE_TASK') {
    chrome.storage.local.get(['kazistack-tasks'], r => {
      const tasks = r['kazistack-tasks'] || [];
      const updated = tasks.map(t =>
        t.id === msg.taskId
          ? { ...t, ...msg.updates, updatedAt: new Date().toISOString() }
          : t
      );
      
      chrome.storage.local.set({ 'kazistack-tasks': updated }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Update error:', chrome.runtime.lastError);
          sendResponse({ success: false, error: chrome.runtime.lastError });
        } else {
          console.log('✏️ Updated task:', msg.taskId);
          
          // Notify all tabs about the update
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              if (tab.url && !tab.url.includes('chrome://')) {
                chrome.tabs.sendMessage(tab.id, { 
                  type: 'TASKS_UPDATED', 
                  tasks: updated 
                }).catch(() => {});
              }
            });
          });
          
          sendResponse({ tasks: updated, success: true });
        }
      });
    });
    return true;
  }

  // Clear all tasks (for testing)
  if (msg.type === 'CLEAR_TASKS') {
    chrome.storage.local.set({ 'kazistack-tasks': [] }, () => {
      console.log('🧹 Cleared all tasks');
      
      // Notify all tabs about the update
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && !tab.url.includes('chrome://')) {
            chrome.tabs.sendMessage(tab.id, { 
              type: 'TASKS_UPDATED', 
              tasks: [] 
            }).catch(() => {});
          }
        });
      });
      
      sendResponse({ success: true });
    });
    return true;
  }
});

// Check due tasks every minute
chrome.alarms.create('check-due', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'check-due') return;
  
  chrome.storage.local.get(['kazistack-tasks'], r => {
    const tasks = r['kazistack-tasks'] || [];
    const now = new Date();
    
    tasks.forEach(task => {
      if (!task.dueDate || task.status === 'done') return;
      
      try {
        const dueDate = new Date(task.dueDate);
        const diff = (dueDate - now) / 60000; // minutes
        
        // Notify if due in the next minute
        if (diff > 0 && diff <= 1) {
          chrome.notifications.create(`due-${task.id}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: `⏰ ${task.title}`,
            message: `Due now · ${task.priority} priority`,
            buttons: [{ title: '✓ Mark Done' }],
            requireInteraction: true,
            priority: 2
          });
        }
        
        // Also notify if overdue (negative diff)
        if (diff < 0 && diff > -60) { // Overdue by less than an hour
          chrome.notifications.create(`overdue-${task.id}`, {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: `⚠️ OVERDUE: ${task.title}`,
            message: `Was due ${Math.abs(Math.round(diff))} minutes ago · ${task.priority} priority`,
            buttons: [{ title: '✓ Mark Done' }],
            requireInteraction: true,
            priority: 2
          });
        }
      } catch (e) {
        console.error('Error checking due date for task:', task.id, e);
      }
    });
  });
});

// Handle notification button clicks
chrome.notifications.onButtonClicked.addListener((notifId, btnIdx) => {
  if (btnIdx !== 0) return; // Only first button (Mark Done)
  
  const taskId = notifId.replace('due-', '').replace('overdue-', '');
  
  chrome.storage.local.get(['kazistack-tasks'], r => {
    const tasks = r['kazistack-tasks'] || [];
    const updated = tasks.map(t =>
      t.id === taskId ? { ...t, status: 'done', completedAt: new Date().toISOString() } : t
    );
    
    chrome.storage.local.set({ 'kazistack-tasks': updated }, () => {
      chrome.notifications.clear(notifId);
      console.log('✅ Task completed via notification:', taskId);
      
      // Notify all tabs about the update
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && !tab.url.includes('chrome://')) {
            chrome.tabs.sendMessage(tab.id, { 
              type: 'TASKS_UPDATED', 
              tasks: updated 
            }).catch(() => {});
          }
        });
      });
    });
  });
});

// Handle notification clicks (not just buttons)
chrome.notifications.onClicked.addListener(notifId => {
  // Open the app when notification is clicked (not button)
  chrome.tabs.create({ url: 'https://kazistack.vercel.app' });
});

// Clean up old notifications when extension starts
chrome.notifications.getAll(notifications => {
  Object.keys(notifications).forEach(id => {
    chrome.notifications.clear(id);
  });
});

// Handle extension install/update
chrome.runtime.onInstalled.addListener(details => {
  console.log('📦 Extension installed/updated:', details.reason);
  
  // Initialize storage if needed
  chrome.storage.local.get(['kazistack-tasks'], r => {
    if (!r['kazistack-tasks']) {
      chrome.storage.local.set({ 'kazistack-tasks': [] });
      console.log('📁 Initialized empty tasks storage');
    }
  });
  
  // Show welcome notification on install
  if (details.reason === 'install') {
    chrome.notifications.create('welcome', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '🎉 Welcome to TaskFlow!',
      message: 'Click to open the app and start managing your tasks',
      buttons: [{ title: 'Open TaskFlow' }],
      requireInteraction: false
    });
  }
});

// Handle browser startup
chrome.runtime.onStartup.addListener(() => {
  console.log('🔄 Browser started, TaskFlow ready');
});

// Keep service worker alive
let keepAliveInterval = setInterval(() => {
  chrome.storage.local.get(['kazistack-tasks'], () => {
    // Just a dummy operation to keep SW alive
  });
}, 20000);

// Clean up on suspend
self.addEventListener('beforeunload', () => {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
});

console.log('✅ TaskFlow background fully initialized');
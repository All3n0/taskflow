(function () {
  if (document.getElementById('tf-root')) return;

  let tasks = [];
  let open = false;

  function isToday(str) {
    if (!str) return false;
    const d = new Date(str), n = new Date();
    return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  }
  function isOverdue(t) {
    return t.dueDate && t.status !== 'done' && new Date(t.dueDate) < new Date();
  }
  function fmtTime(str) {
    const d = new Date(str);
    if (d.getHours() === 23 && d.getMinutes() === 59) return '';
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  }

  const COLORS = { urgent:'#ef4444', high:'#f59e0b', medium:'#6366f1', low:'#94a3b8' };

  // ── DOM ──────────────────────────────────────────────────────
  const root = document.createElement('div');
  root.id = 'tf-root';
  root.innerHTML = `
    <button id="tf-fab" title="TaskFlow">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
      </svg>
      <span id="tf-badge"></span>
    </button>

    <div id="tf-panel">
      <div id="tf-head">
        <div>
          <div id="tf-head-title">TaskFlow</div>
          <div id="tf-head-date"></div>
        </div>
        <div style="display:flex;gap:4px;align-items:center">
          <button id="tf-open" title="Open app">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
            </svg>
          </button>
          <button id="tf-x">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div id="tf-no-tasks" style="display:none">
        <div id="tf-no-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
          </svg>
        </div>
        <p>All clear for today!</p>
        <span>No tasks due</span>
      </div>

      <div id="tf-no-sync" style="display:none">
        <div id="tf-no-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 2v6h-6"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M3 22v-6h6"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/>
          </svg>
        </div>
        <p>Not synced yet</p>
        <span>Open kazistack to sync</span>
        <button id="tf-go-app">Open kazistack →</button>
      </div>

      <div id="tf-list"></div>

      <div id="tf-foot">
        <div id="tf-foot-text"></div>
        <div id="tf-prog-wrap"><div id="tf-prog"></div></div>
      </div>
    </div>
  `;
  document.body.appendChild(root);

  document.getElementById('tf-head-date').textContent =
    new Date().toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric' });

  // ── Render ───────────────────────────────────────────────────
  function render() {
    const today = tasks
      .filter(t => t.status !== 'done' && (isToday(t.dueDate) || isOverdue(t)))
      .sort((a, b) => {
        if (isOverdue(a) !== isOverdue(b)) return isOverdue(a) ? -1 : 1;
        const p = { urgent:0, high:1, medium:2, low:3 };
        return (p[a.priority]||2) - (p[b.priority]||2);
      });

    const badge = document.getElementById('tf-badge');
    if (today.length > 0) {
      badge.textContent = today.length > 9 ? '9+' : today.length;
      badge.style.display = 'flex';
      badge.style.background = today.some(isOverdue) ? '#ef4444' : '#6366f1';
    } else {
      badge.style.display = 'none';
    }

    const list     = document.getElementById('tf-list');
    const noTasks  = document.getElementById('tf-no-tasks');
    const noSync   = document.getElementById('tf-no-sync');
    const foot     = document.getElementById('tf-foot');

    if (tasks.length === 0) {
      list.style.display = 'none';
      noTasks.style.display = 'none';
      noSync.style.display = 'flex';
      foot.style.display = 'none';
      return;
    }

    noSync.style.display = 'none';

    if (today.length === 0) {
      list.style.display = 'none';
      noTasks.style.display = 'flex';
      foot.style.display = 'none';
      return;
    }

    noTasks.style.display = 'none';
    list.style.display = 'block';
    foot.style.display = 'block';

    list.innerHTML = today.map(task => {
      const over  = isOverdue(task);
      const color = COLORS[task.priority] || '#6366f1';
      const time  = task.dueDate ? fmtTime(task.dueDate) : '';
      return `
        <div class="tf-item${over ? ' tf-over' : ''}" data-id="${task.id}">
          <button class="tf-chk" data-id="${task.id}">
            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </button>
          <div class="tf-bar" style="background:${color}"></div>
          <div class="tf-info">
            <span class="tf-name">${task.title}</span>
            <div class="tf-meta">
              <span style="color:${color};font-weight:700;font-size:10px;text-transform:capitalize">${task.priority}</span>
              ${time ? `<span class="tf-time${over?' tf-late':''}">${over?'⚠ ':''}${time}</span>` : ''}
              ${over ? '<span class="tf-tag">Overdue</span>' : ''}
            </div>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.tf-chk').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const el = document.querySelector(`.tf-item[data-id="${id}"]`);
        if (el) { el.style.opacity = '0'; el.style.transform = 'translateX(16px)'; }
        setTimeout(() => {
          chrome.runtime.sendMessage({ type: 'MARK_DONE', taskId: id }, res => {
            if (res?.tasks) { tasks = res.tasks; render(); }
          });
        }, 250);
      });
    });

    // Footer progress
    const done  = tasks.filter(t => t.status === 'done' && isToday(t.completedAt)).length;
    const total = today.length + done;
    const pct   = total > 0 ? Math.round((done / total) * 100) : 0;
    document.getElementById('tf-foot-text').textContent = `${done} of ${total} done today`;
    document.getElementById('tf-prog').style.width = `${pct}%`;
  }

  function load() {
    chrome.runtime.sendMessage({ type: 'GET_TASKS' }, res => {
      tasks = res?.tasks || [];
      render();
    });
  }

  // ── Events ───────────────────────────────────────────────────
  document.getElementById('tf-fab').addEventListener('click', e => {
    e.stopPropagation();
    open = !open;
    document.getElementById('tf-panel').classList.toggle('tf-show', open);
    if (open) load();
  });

  document.getElementById('tf-x').addEventListener('click', () => {
    open = false;
    document.getElementById('tf-panel').classList.remove('tf-show');
  });

  const openApp = () => window.open('https://kazistack.vercel.app', '_blank');
  document.getElementById('tf-open').addEventListener('click', openApp);
  document.getElementById('tf-go-app')?.addEventListener('click', openApp);

  document.addEventListener('click', e => {
    if (open && !root.contains(e.target)) {
      open = false;
      document.getElementById('tf-panel').classList.remove('tf-show');
    }
  });

  load();
})();
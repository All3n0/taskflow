(function () {
  if (document.getElementById('tf-root')) return;

  let tasks = [];
  let open = false;

  function isToday(str) {
    if (!str) return false;
    const d = new Date(str), n = new Date();
    return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  }
  function isOverdue(t) {
    return t.dueDate && t.status !== 'done' && new Date(t.dueDate) < new Date();
  }
  function fmtTime(str) {
    const d = new Date(str);
    if (d.getHours() === 23 && d.getMinutes() === 59) return '';
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  }

  const COLORS = { 
    urgent: '#ef4444', 
    high: '#f59e0b', 
    medium: '#3b82f6', 
    low: '#6b7280' 
  };

  // Generate unique ID
  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
  }

  // Listen for updates from background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'TASKS_UPDATED') {
      console.log('📥 Extension received tasks update');
      tasks = msg.tasks;
      render();
    }
  });

  // Inject styles
  const style = document.createElement('style');
  style.textContent = `
    #tf-root * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    /* FAB */
    #tf-fab {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 44px;
      height: 44px;
      border-radius: 22px;
      background: #3b82f6;
      color: white;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
      z-index: 999999;
    }

    #tf-fab svg {
      width: 18px;
      height: 18px;
    }

    #tf-fab:hover {
      background: #2563eb;
      transform: scale(1.05);
    }

    /* Badge */
    #tf-badge {
      position: absolute;
      top: -3px;
      right: -3px;
      min-width: 16px;
      height: 16px;
      border-radius: 8px;
      background: #ef4444;
      color: white;
      font-size: 9px;
      font-weight: 700;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 0 3px;
      border: 1.5px solid #1a1a1a;
    }

    /* Panel */
    #tf-panel {
      position: fixed;
      bottom: 72px;
      right: 20px;
      width: 320px;
      background: #111111;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
      border: 1px solid #2a2a2a;
      opacity: 0;
      transform: scale(0.95) translateY(10px);
      transform-origin: bottom right;
      transition: all 0.15s ease;
      pointer-events: none;
      z-index: 999998;
      color: #e5e5e5;
    }

    #tf-panel.tf-show {
      opacity: 1;
      transform: scale(1) translateY(0);
      pointer-events: all;
    }

    /* Header */
    #tf-head {
      padding: 12px 16px;
      border-bottom: 1px solid #2a2a2a;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #111111;
    }

    #tf-head-title {
      font-weight: 600;
      font-size: 14px;
      color: #ffffff;
    }

    #tf-head-date {
      font-size: 11px;
      color: #9ca3af;
      margin-top: 2px;
    }

    #tf-head-actions {
      display: flex;
      gap: 4px;
    }

    #tf-add-btn, #tf-open, #tf-x {
      background: #1f1f1f;
      border: none;
      width: 28px;
      height: 28px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      color: #9ca3af;
      transition: all 0.2s;
    }

    #tf-add-btn svg, #tf-open svg, #tf-x svg {
      width: 12px;
      height: 12px;
    }

    #tf-add-btn:hover {
      background: #3b82f6;
      color: white;
    }

    #tf-open:hover, #tf-x:hover {
      background: #2a2a2a;
      color: #ffffff;
    }

    /* Add Task Form */
    #tf-add-form {
      padding: 16px;
      border-bottom: 1px solid #2a2a2a;
      background: #0a0a0a;
    }

    #tf-add-form input,
    #tf-add-form textarea,
    #tf-add-form select {
      width: 100%;
      background: #1a1a1a;
      border: 1px solid #2a2a2a;
      border-radius: 8px;
      padding: 8px 12px;
      color: white;
      font-size: 12px;
      margin-bottom: 8px;
    }

    #tf-add-form input:focus,
    #tf-add-form textarea:focus,
    #tf-add-form select:focus {
      outline: none;
      border-color: #3b82f6;
    }

    #tf-add-form textarea {
      min-height: 60px;
      resize: vertical;
    }

    #tf-form-row {
      display: flex;
      gap: 8px;
      margin-bottom: 8px;
    }

    #tf-form-row select {
      flex: 1;
      margin-bottom: 0;
    }

    #tf-form-row input[type="datetime-local"] {
      flex: 2;
      margin-bottom: 0;
      color-scheme: dark;
    }

    #tf-form-actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    }

    #tf-form-actions button {
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      transition: all 0.2s;
    }

    #tf-form-save {
      background: #3b82f6;
      color: white;
    }

    #tf-form-save:hover {
      background: #2563eb;
    }

    #tf-form-cancel {
      background: #1f1f1f;
      color: #9ca3af;
    }

    #tf-form-cancel:hover {
      background: #2a2a2a;
      color: white;
    }

    /* Empty states */
    #tf-no-sync, #tf-no-tasks {
      padding: 32px 16px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      background: #111111;
    }

    #tf-no-icon {
      width: 40px;
      height: 40px;
      border-radius: 20px;
      background: #1f1f1f;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #3b82f6;
      margin-bottom: 12px;
    }

    #tf-no-icon svg {
      width: 20px;
      height: 20px;
      stroke: #3b82f6;
    }

    #tf-no-sync p, #tf-no-tasks p {
      font-weight: 600;
      font-size: 13px;
      color: #ffffff;
      margin-bottom: 2px;
    }

    #tf-no-sync span, #tf-no-tasks span {
      font-size: 11px;
      color: #9ca3af;
    }

    /* Open app button */
    #tf-go-app {
      margin-top: 12px;
      padding: 8px 16px;
      border-radius: 16px;
      background: #3b82f6;
      color: white;
      border: none;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    #tf-go-app:hover {
      background: #2563eb;
    }

    /* Task list */
    #tf-list {
      padding: 8px;
      max-height: 300px;
      overflow-y: auto;
      background: #111111;
    }

    /* Task item */
    .tf-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 10px;
      margin: 2px 0;
      background: #1a1a1a;
      border-radius: 10px;
      border: 1px solid #2a2a2a;
      transition: all 0.15s;
    }

    .tf-item:hover {
      background: #1f1f1f;
      border-color: #3a3a3a;
    }

    .tf-item.tf-over {
      background: rgba(239, 68, 68, 0.1);
      border-left: 2px solid #ef4444;
    }

    /* Check button */
    .tf-chk {
      width: 18px;
      height: 18px;
      border-radius: 9px;
      border: 1.5px solid #3a3a3a;
      background: transparent;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
      flex-shrink: 0;
      padding: 0;
    }

    .tf-chk:hover {
      border-color: #3b82f6;
      background: rgba(59, 130, 246, 0.2);
    }

    .tf-chk svg {
      width: 10px;
      height: 10px;
      stroke: #3b82f6;
      opacity: 0;
    }

    .tf-chk:hover svg {
      opacity: 1;
    }

    /* Priority bar */
    .tf-bar {
      width: 2px;
      height: 20px;
      border-radius: 2px;
      flex-shrink: 0;
    }

    /* Task info */
    .tf-info {
      flex: 1;
      min-width: 0;
    }

    .tf-name {
      font-size: 12px;
      font-weight: 500;
      color: #ffffff;
      display: block;
      margin-bottom: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .tf-meta {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 9px;
    }

    .tf-time {
      color: #9ca3af;
      font-size: 8px;
      background: #1f1f1f;
      padding: 2px 6px;
      border-radius: 10px;
    }

    .tf-time.tf-late {
      color: #ef4444;
      background: rgba(239, 68, 68, 0.15);
    }

    .tf-tag {
      font-size: 7px;
      font-weight: 600;
      text-transform: uppercase;
      background: #ef4444;
      color: white;
      padding: 2px 6px;
      border-radius: 8px;
      letter-spacing: 0.2px;
    }

    /* Footer */
    #tf-foot {
      padding: 12px 16px;
      border-top: 1px solid #2a2a2a;
      background: #111111;
    }

    #tf-foot-text {
      font-size: 10px;
      color: #9ca3af;
      margin-bottom: 6px;
      font-weight: 500;
    }

    #tf-prog-wrap {
      width: 100%;
      height: 3px;
      background: #1f1f1f;
      border-radius: 2px;
      overflow: hidden;
    }

    #tf-prog {
      height: 100%;
      background: #3b82f6;
      border-radius: 2px;
      width: 0%;
      transition: width 0.3s;
    }

    /* Scrollbar */
    #tf-list::-webkit-scrollbar {
      width: 3px;
    }

    #tf-list::-webkit-scrollbar-track {
      background: #1a1a1a;
    }

    #tf-list::-webkit-scrollbar-thumb {
      background: #3a3a3a;
      border-radius: 2px;
    }

    #tf-list::-webkit-scrollbar-thumb:hover {
      background: #4a4a4a;
    }
  `;
  document.head.appendChild(style);

  // ── DOM ──────────────────────────────────────────────────────
  const root = document.createElement('div');
  root.id = 'tf-root';
  root.innerHTML = `
    <button id="tf-fab" title="TaskFlow">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
      </svg>
      <span id="tf-badge"></span>
    </button>

    <div id="tf-panel">
      <div id="tf-head">
        <div>
          <div id="tf-head-title">TaskFlow</div>
          <div id="tf-head-date"></div>
        </div>
        <div id="tf-head-actions">
          <button id="tf-add-btn" title="Add task">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </button>
          <button id="tf-open" title="Open app">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
            </svg>
          </button>
          <button id="tf-x">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Add Task Form (hidden by default) -->
      <div id="tf-add-form" style="display: none;">
        <input type="text" id="tf-task-title" placeholder="Task title..." autocomplete="off">
        <textarea id="tf-task-desc" placeholder="Description (optional)"></textarea>
        <div id="tf-form-row">
          <select id="tf-task-priority">
            <option value="low">Low</option>
            <option value="medium" selected>Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
          <input type="datetime-local" id="tf-task-due">
        </div>
        <div id="tf-form-actions">
          <button id="tf-form-cancel">Cancel</button>
          <button id="tf-form-save">Add Task</button>
        </div>
      </div>

      <div id="tf-no-sync" style="display:none">
        <div id="tf-no-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M21 2v6h-6"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M3 22v-6h6"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/>
          </svg>
        </div>
        <p>Not synced</p>
        <span>Open app to sync</span>
        <button id="tf-go-app">Open →</button>
      </div>

      <div id="tf-no-tasks" style="display:none">
        <div id="tf-no-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
          </svg>
        </div>
        <p>All clear!</p>
        <span>No tasks due</span>
      </div>

      <div id="tf-list"></div>

      <div id="tf-foot">
        <div id="tf-foot-text"></div>
        <div id="tf-prog-wrap"><div id="tf-prog"></div></div>
      </div>
    </div>
  `;
  document.body.appendChild(root);

  document.getElementById('tf-head-date').textContent =
    new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

  // ── Add Task Function ─────────────────────────────────────────
  function showAddForm() {
    document.getElementById('tf-add-form').style.display = 'block';
    document.getElementById('tf-task-title').focus();
  }

  function hideAddForm() {
    document.getElementById('tf-add-form').style.display = 'none';
    // Clear form
    document.getElementById('tf-task-title').value = '';
    document.getElementById('tf-task-desc').value = '';
    document.getElementById('tf-task-priority').value = 'medium';
    document.getElementById('tf-task-due').value = '';
  }

  function addNewTask() {
    const title = document.getElementById('tf-task-title').value.trim();
    if (!title) return;

    const newTask = {
      id: generateId(),
      title: title,
      description: document.getElementById('tf-task-desc').value.trim() || '',
      status: 'todo',
      priority: document.getElementById('tf-task-priority').value,
      dueDate: document.getElementById('tf-task-due').value || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      completedAt: null,
      timeTracking: {
        totalTime: 0,
        isRunning: false,
        entries: []
      }
    };

    // Add to tasks array
    tasks.push(newTask);
    
    // Send to background to save and broadcast
    chrome.runtime.sendMessage({ 
      type: 'ADD_TASK', 
      task: newTask 
    }, (response) => {
      if (response?.success) {
        console.log('✅ Task added and synced');
        tasks = response.tasks; // Update with server response
        render();
      }
    });

    hideAddForm();
  }

  // ── Render ───────────────────────────────────────────────────
  function render() {
    const today = tasks
      .filter(t => t.status !== 'done' && (isToday(t.dueDate) || isOverdue(t)))
      .sort((a, b) => {
        if (isOverdue(a) !== isOverdue(b)) return isOverdue(a) ? -1 : 1;
        const p = { urgent: 0, high: 1, medium: 2, low: 3 };
        return (p[a.priority] || 2) - (p[b.priority] || 2);
      });

    const badge = document.getElementById('tf-badge');
    if (today.length > 0) {
      badge.textContent = today.length > 9 ? '9+' : today.length;
      badge.style.display = 'flex';
      badge.style.background = today.some(isOverdue) ? '#ef4444' : '#3b82f6';
    } else {
      badge.style.display = 'none';
    }

    const list = document.getElementById('tf-list');
    const noTasks = document.getElementById('tf-no-tasks');
    const noSync = document.getElementById('tf-no-sync');
    const foot = document.getElementById('tf-foot');

    if (tasks.length === 0) {
      list.style.display = 'none';
      noTasks.style.display = 'none';
      noSync.style.display = 'flex';
      foot.style.display = 'none';
      return;
    }

    noSync.style.display = 'none';

    if (today.length === 0) {
      list.style.display = 'none';
      noTasks.style.display = 'flex';
      foot.style.display = 'none';
      return;
    }

    noTasks.style.display = 'none';
    list.style.display = 'block';
    foot.style.display = 'block';

    list.innerHTML = today.map(task => {
      const over = isOverdue(task);
      const color = COLORS[task.priority] || '#3b82f6';
      const time = task.dueDate ? fmtTime(task.dueDate) : '';
      
      return `
        <div class="tf-item${over ? ' tf-over' : ''}" data-id="${task.id}">
          <button class="tf-chk" data-id="${task.id}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </button>
          <div class="tf-bar" style="background:${color}"></div>
          <div class="tf-info">
            <span class="tf-name">${task.title}</span>
            <div class="tf-meta">
              <span class="tf-time" style="color:${color}">● ${task.priority}</span>
              ${time ? `<span class="tf-time${over ? ' tf-late' : ''}">${over ? '⚠ ' : ''}${time}</span>` : ''}
              ${over ? '<span class="tf-tag">overdue</span>' : ''}
            </div>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.tf-chk').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const el = document.querySelector(`.tf-item[data-id="${id}"]`);
        if (el) {
          el.style.opacity = '0';
          el.style.transform = 'translateX(8px)';
        }
        setTimeout(() => {
          chrome.runtime.sendMessage({ type: 'MARK_DONE', taskId: id }, res => {
            if (res?.tasks) {
              tasks = res.tasks;
              render();
            }
          });
        }, 150);
      });
    });

    // Footer progress
    const done = tasks.filter(t => t.status === 'done' && isToday(t.completedAt)).length;
    const total = today.length + done;
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    document.getElementById('tf-foot-text').textContent = `${done}/${total} done`;
    document.getElementById('tf-prog').style.width = `${pct}%`;
  }

  function load() {
    chrome.runtime.sendMessage({ type: 'GET_TASKS' }, res => {
      tasks = res?.tasks || [];
      render();
    });
  }

  // ── Events ───────────────────────────────────────────────────
  document.getElementById('tf-fab').addEventListener('click', e => {
    e.stopPropagation();
    open = !open;
    document.getElementById('tf-panel').classList.toggle('tf-show', open);
    if (open) {
      load();
      hideAddForm();
    }
  });

  document.getElementById('tf-x').addEventListener('click', () => {
    open = false;
    document.getElementById('tf-panel').classList.remove('tf-show');
    hideAddForm();
  });

  document.getElementById('tf-add-btn').addEventListener('click', showAddForm);
  document.getElementById('tf-form-cancel').addEventListener('click', hideAddForm);
  document.getElementById('tf-form-save').addEventListener('click', addNewTask);

  document.getElementById('tf-task-title').addEventListener('keypress', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addNewTask();
    }
  });

  const openApp = () => window.open('https://kazistack.vercel.app', '_blank');
  document.getElementById('tf-open').addEventListener('click', openApp);
  document.getElementById('tf-go-app')?.addEventListener('click', openApp);

  document.addEventListener('click', e => {
    if (open && !root.contains(e.target)) {
      open = false;
      document.getElementById('tf-panel').classList.remove('tf-show');
      hideAddForm();
    }
  });

  load();
})();